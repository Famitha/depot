Given /^I am in New page$/ do
  visit '/paypals/new'
end
Then /^I should see "([^"]*)" button/ do |name|
  find_button(name)
end
